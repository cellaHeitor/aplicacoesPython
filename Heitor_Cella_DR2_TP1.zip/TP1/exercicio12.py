desconto_txt = '19';
desconto_num = float(desconto_txt) / 3.14;

resultado = 599.99 - desconto_num;

print(desconto_num)
print(resultado);