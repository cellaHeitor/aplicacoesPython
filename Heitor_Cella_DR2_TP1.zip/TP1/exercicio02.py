nome_cliente = 'Heitor Cella Oliveira';
idade_cliente = 19;
score_credito = 772.4;
cliente_ativo = True;

print('Nome:', nome_cliente, '-', type(nome_cliente))
print('Idade:', idade_cliente, '-', type(idade_cliente))
print('Nome:', score_credito, '-', type(score_credito))
print('Nome:', cliente_ativo, '-', type(cliente_ativo))