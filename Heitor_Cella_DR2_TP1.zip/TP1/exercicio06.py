nome = 'Heitor';
sobrenome = 'Oliveira';
codigoTurma = '25E3_2';

print('Bem-vindo(a) ' + nome + ' '+ sobrenome + '! Sua turma é ' + codigoTurma)