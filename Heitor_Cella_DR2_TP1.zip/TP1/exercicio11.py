ano_txt = '2006';
ano_int = int(ano_txt);

soma = ano_int + 5;

print(soma)