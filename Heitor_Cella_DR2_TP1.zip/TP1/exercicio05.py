msg_aspas_simples = 'Projeto "Heitor Cella Oliveira" em execução';
msg_aspas_duplas = 'Aluno "Heitor Cella Oliveira" aprovado no teste';
relatorio_triple = """Título: Projeto de Pesquisa
Descrição: Este projeto tem como ideia o teste de strings com diferentes inserções de aspas.
Status: Concluído com sucesso""";

print(msg_aspas_simples);
print(msg_aspas_duplas);
print(relatorio_triple);