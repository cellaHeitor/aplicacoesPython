habilidades = 'Domínio em Python, SQL e Excel.';
busca = 'Python';

print(busca in habilidades);