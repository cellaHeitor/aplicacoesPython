nome_estagiario = 'Heitor Cella Oliveira';
idade_estagiario = 19;
codigo_departamento = '25E3_2';

print('===== Estagiario Cadastrado =====');
print('Nome:', nome_estagiario);
print('Idade:', idade_estagiario);
print('Código Departamento:', codigo_departamento); 
