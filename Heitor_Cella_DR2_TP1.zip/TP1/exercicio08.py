nome_completo = 'Heitor Oliveira';

print(f"{nome_completo.upper()}");
print(f"{nome_completo.lower()}");
print(f"{nome_completo.title()}");
print(f"{nome_completo.capitalize()}");
print(f"{nome_completo.swapcase()}");

