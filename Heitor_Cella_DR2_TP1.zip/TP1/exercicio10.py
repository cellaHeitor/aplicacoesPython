opiniao = 'Serviço excelente aluno Heitor Cella Oliveira, voltarei a comprar!';

print(len(opiniao));
print(opiniao.count(" ") + 1);
