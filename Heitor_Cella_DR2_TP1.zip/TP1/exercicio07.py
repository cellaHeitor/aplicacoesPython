alerta = 'ATENÇÃO!';
faixa_alerta = alerta * 5;

print(faixa_alerta);